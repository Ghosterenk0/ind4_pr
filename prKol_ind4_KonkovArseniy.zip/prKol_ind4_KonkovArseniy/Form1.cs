﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind4_FI
{
    public partial class Form1 : Form
    {
        private Hashtable catalog = new Hashtable();
        public Form1()
        {
            InitializeComponent();
            ButtonAddDisk.Click += ButtonAddSong_Click;
            ButtonRemoveDisk.Click += ButtonRemoveDisk_Click;
            ButtonAddSong.Click += ButtonAddSong_Click;
            ButtonRemoveSong.Click += ButtonRemoveSong_Click;
            ButtonShowCatalog.Click += ButtonShowCatalog_Click;
            ButtonSearchArtist.Click += ButtonSearchEX_Click;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        private void AddDisk(string diskName)
        {
            if (string.IsNullOrWhiteSpace(diskName))
            {
                MessageBox.Show("Введите название диска");
            }
            if (catalog.ContainsKey(diskName))
            {
                MessageBox.Show("Диск с таким названием существует");
            }
            catalog[diskName] = new List<Song>();
            UpdateDiskList();
            MessageBox.Show($"Диск - {diskName} добавлен");
        }
        private void RemoveDisk(string diskName)
        {
            if (catalog.ContainsKey(diskName))
            {
                catalog.Remove(diskName);
                UpdateDiskList();
                ClearSongList();
                MessageBox.Show($"Диск - {diskName} удалён");
            }
            else
            {
                MessageBox.Show("Диск не найден");
            }
        }
        private void AddSong(string diskName, string songName, string executor)
        {
            if (string.IsNullOrWhiteSpace(songName) || string.IsNullOrWhiteSpace(executor))
            {
                MessageBox.Show("Введите название песни и имя исполнителя");
                return;
            }
            if (!catalog.ContainsKey(diskName))
            {
                MessageBox.Show("Выберите диск");
                return;
            }
            var songs = (List<Song>)catalog[diskName];
            songs.Add(new Song(songName, executor));
            UpdateSongList(diskName);
            MessageBox.Show($"Песня {diskName} добавлена");
        }
        private void RemoveSong(string diskName, string songName)
        {
            if (!catalog.ContainsKey(diskName))
            {
                MessageBox.Show("Диск не найден");
            }
            var songs = (List<Song>)catalog[diskName];
            var songToRemove = songs.FirstOrDefault(s => s.Name.Equals(songName, StringComparison.OrdinalIgnoreCase));
            if (songToRemove != null)
            {
                songs.Remove(songToRemove);
                UpdateSongList(diskName);
                MessageBox.Show($"Песня {songName} удалена");
            }
            else
            {
                MessageBox.Show("Песня не найдена");
            }
        }
        private void UpdateDiskList()
        {
            listBox1.Items.Clear();
            foreach (string disk in catalog.Keys)
            {
                listBox1.Items.Add(disk);
            }
        }
        private void UpdateSongList(string diskName)
        {
            listBox2.Items.Clear();
            if (catalog.ContainsKey(diskName))
            {
                var songs = (List<Song>)catalog[diskName];
                foreach (var song in songs)
                {
                    listBox2.Items.Add(song.ToString());
                }
            }
        }
        private void ClearSongList()
        {
            listBox2.Items.Clear();
        }
        private void ShowFullCatalog()
        {
            richTextBoxCatalog.Clear();
            foreach (string disk in catalog.Keys)
            {
                richTextBoxCatalog.AppendText($"Диск: {disk}\n");
                var songs = (List<Song>)catalog[disk];
                foreach (var song in songs)
                {
                    richTextBoxCatalog.AppendText($"  {song}\n");
                }
                richTextBoxCatalog.AppendText("\n");
            }
        }
        private void SearchByEX(string artist)
        {
            if (string.IsNullOrWhiteSpace(artist))
            {
                MessageBox.Show("Введите имя исполнителя для поиска");
            }
            richTextBoxCatalog.Clear();
            var f = false;
            foreach (string disk in catalog.Keys)
            {
                var songList = (List<Song>)catalog[disk];
                var exSong = songList.Where(s => s.Executor.Equals(artist, StringComparison.OrdinalIgnoreCase)).ToList();

                if (exSong.Count > 0)
                {
                    f = true;
                    richTextBoxCatalog.AppendText($"Диск: {disk}\n");
                    foreach (var s in exSong)
                    {
                        richTextBoxCatalog.AppendText($"  {s.Name}\n");
                    }
                    richTextBoxCatalog.AppendText("\n");
                }
            }
            if (f == false)
            {
                richTextBoxCatalog.AppendText("Песни данного исполнителя не найдены");
            }
        }
        private void ButtonAddDisk_Click(object sender, EventArgs e)
        {
            AddDisk(textBoxDiskName.Text.Trim());
        }
        private void ButtonRemoveDisk_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                RemoveDisk(listBox1.SelectedItem.ToString());
            }
            else
            {
                MessageBox.Show("Выберите диск для удаления");
            }
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                UpdateSongList(listBox1.SelectedItem.ToString());
            }
            else
            {
                ClearSongList();
            }
        }
        private void ButtonAddSong_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите диск");
            }

            AddSong(listBox1.SelectedItem.ToString(), textBoxSongTitle.Text.Trim(), textBoxArtist.Text.Trim());
        }
        private void ButtonRemoveSong_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите диск");
            }
            if (listBox2.SelectedItem == null)
            {
                MessageBox.Show("Выберите песню для удаления");
            }
            var songS = listBox2.SelectedItem.ToString();
            var songName = songS.Split('-')[0];
            RemoveSong(listBox1.SelectedItem.ToString(), songName);
        }
        private void ButtonShowCatalog_Click(object sender, EventArgs e)
        {
            ShowFullCatalog();
        }
        private void ButtonSearchEX_Click(object sender, EventArgs e)
        {
            SearchByEX(textBoxSearchArtist.Text.Trim());
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                UpdateSongList(listBox1.SelectedItem.ToString());
            }
            else
            {
                ClearSongList();
            }
        }
    }
}
