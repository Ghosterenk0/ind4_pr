﻿namespace prKol_ind4_FI
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxDiskName = new System.Windows.Forms.TextBox();
            this.ButtonAddDisk = new System.Windows.Forms.Button();
            this.ButtonRemoveDisk = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBoxSongTitle = new System.Windows.Forms.TextBox();
            this.textBoxArtist = new System.Windows.Forms.TextBox();
            this.ButtonAddSong = new System.Windows.Forms.Button();
            this.ButtonRemoveSong = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.richTextBoxCatalog = new System.Windows.Forms.RichTextBox();
            this.textBoxSearchArtist = new System.Windows.Forms.TextBox();
            this.ButtonSearchArtist = new System.Windows.Forms.Button();
            this.ButtonShowCatalog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxDiskName
            // 
            this.textBoxDiskName.Location = new System.Drawing.Point(9, 314);
            this.textBoxDiskName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxDiskName.Name = "textBoxDiskName";
            this.textBoxDiskName.Size = new System.Drawing.Size(192, 20);
            this.textBoxDiskName.TabIndex = 0;
            // 
            // ButtonAddDisk
            // 
            this.ButtonAddDisk.Location = new System.Drawing.Point(9, 337);
            this.ButtonAddDisk.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonAddDisk.Name = "ButtonAddDisk";
            this.ButtonAddDisk.Size = new System.Drawing.Size(87, 48);
            this.ButtonAddDisk.TabIndex = 1;
            this.ButtonAddDisk.Text = "Добавить диск";
            this.ButtonAddDisk.UseVisualStyleBackColor = true;
            // 
            // ButtonRemoveDisk
            // 
            this.ButtonRemoveDisk.Location = new System.Drawing.Point(116, 337);
            this.ButtonRemoveDisk.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonRemoveDisk.Name = "ButtonRemoveDisk";
            this.ButtonRemoveDisk.Size = new System.Drawing.Size(85, 48);
            this.ButtonRemoveDisk.TabIndex = 2;
            this.ButtonRemoveDisk.Text = "Удалить диск";
            this.ButtonRemoveDisk.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(9, 6);
            this.listBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(192, 277);
            this.listBox1.TabIndex = 3;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // textBoxSongTitle
            // 
            this.textBoxSongTitle.Location = new System.Drawing.Point(263, 316);
            this.textBoxSongTitle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxSongTitle.Name = "textBoxSongTitle";
            this.textBoxSongTitle.Size = new System.Drawing.Size(112, 20);
            this.textBoxSongTitle.TabIndex = 4;
            // 
            // textBoxArtist
            // 
            this.textBoxArtist.Location = new System.Drawing.Point(399, 314);
            this.textBoxArtist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxArtist.Name = "textBoxArtist";
            this.textBoxArtist.Size = new System.Drawing.Size(129, 20);
            this.textBoxArtist.TabIndex = 5;
            // 
            // ButtonAddSong
            // 
            this.ButtonAddSong.Location = new System.Drawing.Point(263, 340);
            this.ButtonAddSong.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonAddSong.Name = "ButtonAddSong";
            this.ButtonAddSong.Size = new System.Drawing.Size(112, 45);
            this.ButtonAddSong.TabIndex = 6;
            this.ButtonAddSong.Text = "Добавить песню";
            this.ButtonAddSong.UseVisualStyleBackColor = true;
            // 
            // ButtonRemoveSong
            // 
            this.ButtonRemoveSong.Location = new System.Drawing.Point(399, 338);
            this.ButtonRemoveSong.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonRemoveSong.Name = "ButtonRemoveSong";
            this.ButtonRemoveSong.Size = new System.Drawing.Size(129, 48);
            this.ButtonRemoveSong.TabIndex = 7;
            this.ButtonRemoveSong.Text = "Удалить песню";
            this.ButtonRemoveSong.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(278, 6);
            this.listBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(222, 277);
            this.listBox2.TabIndex = 8;
            // 
            // richTextBoxCatalog
            // 
            this.richTextBoxCatalog.Location = new System.Drawing.Point(572, 62);
            this.richTextBoxCatalog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBoxCatalog.Name = "richTextBoxCatalog";
            this.richTextBoxCatalog.Size = new System.Drawing.Size(234, 201);
            this.richTextBoxCatalog.TabIndex = 9;
            this.richTextBoxCatalog.Text = "";
            // 
            // textBoxSearchArtist
            // 
            this.textBoxSearchArtist.Location = new System.Drawing.Point(572, 291);
            this.textBoxSearchArtist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxSearchArtist.Name = "textBoxSearchArtist";
            this.textBoxSearchArtist.Size = new System.Drawing.Size(223, 20);
            this.textBoxSearchArtist.TabIndex = 10;
            // 
            // ButtonSearchArtist
            // 
            this.ButtonSearchArtist.Location = new System.Drawing.Point(572, 355);
            this.ButtonSearchArtist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonSearchArtist.Name = "ButtonSearchArtist";
            this.ButtonSearchArtist.Size = new System.Drawing.Size(234, 35);
            this.ButtonSearchArtist.TabIndex = 11;
            this.ButtonSearchArtist.Text = "Показать весь каталог";
            this.ButtonSearchArtist.UseVisualStyleBackColor = true;
            // 
            // ButtonShowCatalog
            // 
            this.ButtonShowCatalog.Location = new System.Drawing.Point(572, 320);
            this.ButtonShowCatalog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ButtonShowCatalog.Name = "ButtonShowCatalog";
            this.ButtonShowCatalog.Size = new System.Drawing.Size(234, 31);
            this.ButtonShowCatalog.TabIndex = 12;
            this.ButtonShowCatalog.Text = "Поиск исполнителя";
            this.ButtonShowCatalog.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 299);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Введите название диска";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 299);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Введите название диска";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(569, 276);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Введите исполнителя";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 299);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Введите исполнителя песни";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(649, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 24);
            this.label5.TabIndex = 17;
            this.label5.Text = "Поиск";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 406);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonShowCatalog);
            this.Controls.Add(this.ButtonSearchArtist);
            this.Controls.Add(this.textBoxSearchArtist);
            this.Controls.Add(this.richTextBoxCatalog);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.ButtonRemoveSong);
            this.Controls.Add(this.ButtonAddSong);
            this.Controls.Add(this.textBoxArtist);
            this.Controls.Add(this.textBoxSongTitle);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.ButtonRemoveDisk);
            this.Controls.Add(this.ButtonAddDisk);
            this.Controls.Add(this.textBoxDiskName);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxDiskName;
        private System.Windows.Forms.Button ButtonAddDisk;
        private System.Windows.Forms.Button ButtonRemoveDisk;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBoxSongTitle;
        private System.Windows.Forms.TextBox textBoxArtist;
        private System.Windows.Forms.Button ButtonAddSong;
        private System.Windows.Forms.Button ButtonRemoveSong;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.RichTextBox richTextBoxCatalog;
        private System.Windows.Forms.TextBox textBoxSearchArtist;
        private System.Windows.Forms.Button ButtonSearchArtist;
        private System.Windows.Forms.Button ButtonShowCatalog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

