﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind4_FI
{
    internal class Song
    {
        public string Name { get; set; }
        public string Executor { get; set; }
        public Song(string name, string executor)
        {
            Name = name;
            Executor = executor;
        }
        public override string ToString()
        {
            return $"{Name} - {Executor}";
        }
    }
}
